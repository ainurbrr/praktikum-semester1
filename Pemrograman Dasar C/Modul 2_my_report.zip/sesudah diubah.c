#include <stdio.h>

int hektare_ke_are(int hektare){
	int are;
	
	are = hektare * 100;
	return are;
}
int are_ke_m_persegi(int are){
	int m_persegi;
	
	m_persegi = are * 100;
	return m_persegi;
}
int m_persegi_ke_cm_persegi(int m_persegi){
	int cm_persegi;
	
	cm_persegi = m_persegi * 10000;
	return cm_persegi;
}

int main(){
	int hektare;
	int are;
	int m_persegi;
	int cm_persegi;

	printf("masukkan luas dalam satuan hektare :" );
    scanf("%d", &hektare);

    are = hektare_ke_are(hektare);
    printf("are : %d\n", are);
    m_persegi = are_ke_m_persegi(are);
    printf("m_persegi : %d\n", m_persegi);
    cm_persegi = m_persegi_ke_cm_persegi(m_persegi);
    printf("cm_persegi : %d\n", cm_persegi);

    return 0;
}