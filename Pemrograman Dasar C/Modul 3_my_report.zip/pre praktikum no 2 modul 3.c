#include <stdio.h>
#include <stdlib.h>

int main(){
	
int angka;
printf("kelipatan 2 dari 500-0  :\n");
	for(angka=500; angka>0; angka-=2)
	{	
		printf("%d  ", angka);	
	}	
return 0;
}
